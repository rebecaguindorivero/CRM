(function () {
    'use strict';


    angular.module('CrmUsuario')
        .controller('MainController', MainController);

    MainController.$inject = ['$scope', 'UsuarioFactoria'];

    /* @ngInject */
    function MainController($scope, UsuarioFactoria) {
        $scope.list = [];
        $scope.modificando = false;
        $scope.usuarioNuevo = {};
        $scope.adduser = adduser;
        $scope.modifyUser = modifyUser;
        $scope.editar = editar;
        $scope.eliminar = eliminar;


        activate();

        ////////////////

        function activate() {
            $scope.list = UsuarioFactoria.cargarUsuarios();
        }

        function adduser() {
            /*  Opcion 1: le pongo yo el identificador 
           $scope.usuarioNuevo.identificador = Date.now();
            
            // Esto es para actualizar la pantalla ( $scope.list )
            $scope.list.push($scope.usuarioNuevo);
            
            // Esto es para que la factoría guarde el nuevo usuario ( en este caso en localStorage )
            usuario.nuevoUsuario($scope.usuarioNuevo);

            // vaciar el formulario
            $scope.usuarioNuevo = {};
            
            */

            // Le digo a la factoría que añada un nuevo usuario y el me responde con el identificador
            var identificadorQueSeUso = UsuarioFactoria.nuevoUsuario($scope.usuarioNuevo);

            // Yo le pongo el identificador que la factoría me dijo a mi objeto nuevoUsuario
            $scope.usuarioNuevo.identificador = identificadorQueSeUso;

            // Esto es para actualizar la pantalla ( $scope.list )
            $scope.list.push($scope.usuarioNuevo);

            // vaciar el formulario
            $scope.usuarioNuevo = {};


        }


        function editar(usuario) {
            console.log(usuario);
            $scope.usuarioNuevo = angular.copy(usuario);
            $scope.modificando = true;
        }

        function modifyUser() {

            // Necesito refrescar la pantalla así que lo busco en $scope.list
            for (var i = 0; i < $scope.list.length; i++) {
                var elActual = $scope.list[i];
                var elQueSeEstaEditando = $scope.usuarioNuevo;

                if (elQueSeEstaEditando.identificador == elActual.identificador) {
                    // Lo encontré 
                    
                    // Para actualizar la pantalla, $scope.list
                    $scope.list[i] = elQueSeEstaEditando;

                    // Actualizar lo de localStorage
                    UsuarioFactoria.editarUsuario(elQueSeEstaEditando);

                    // Poner el formulario en blanco y que no salga el botón modificando
                    $scope.usuarioNuevo = {};
                    $scope.modificando = false;

                }
            }
        }

        function eliminar(usuario) {
            var confirmRes = confirm('Estás seguro de que quieres borrarlo?');
            if (confirmRes == true) {
                
                // Lo estamos haciendo para eliminarlo de $scope.list 
                for (var i = 0; i < $scope.list.length; i++) {
                    var elActual = $scope.list[i];
                    var elQueSeVaEliminar = usuario;
                    if (elQueSeVaEliminar.identificador == elActual.identificador) {
                        $scope.list.splice(i, 1);

                        UsuarioFactoria.eliminarUsuario(usuario);
                    }

                }
            } else {
                return false;
            }
        }
        
        


    }
})();
