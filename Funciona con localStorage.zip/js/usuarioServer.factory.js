(function () {
    'use strict';
    angular
        .module('CrmUsuario')
        .factory('usuarioServer', usuario);

    usuario.$inject = ['$http'];

    /* @ngInject */
    function  usuario($http){
        
        var urlServer = 'http://localhost:3000/api/customers';
        
        var exports = {
            get : get,
            put : put,
            post : post,
            remove : remove,
            getAll : getAll
            
           
            
        };
        
    
        

        return exports;

        ////////////////
        
        
        
        // este es el enlace de $http: http://localhost:3000/api/customers.

        function get() {
            
        }
        function put() {
            
        }
        
        
        function remove() {
            
        }
        
        function post() {
            
        }
        
        function getAll() {
            
        }
    }
})();